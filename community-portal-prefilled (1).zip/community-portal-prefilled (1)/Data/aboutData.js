module.exports = [
  { name: 'Alice', role: 'Team Lead' },
  { name: 'Bob', role: 'Backend Developer' },
  { name: 'Charlie', role: 'Frontend Developer' },
  { name: 'Dana', role: 'Data Manager' },
  { name: 'Eli', role: 'Documentation Manager' }
];
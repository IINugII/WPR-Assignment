module.exports = [
  {
    title: 'Community Cleanup',
    date: '2025-05-15',
    location: 'Central Park',
    image: '/images/cleanup.jpg'
  },
  {
    title: 'Charity Run',
    date: '2025-06-01',
    location: 'River Side',
    image: '/images/run.jpg'
  },
  {
    title: 'Summer Fair',
    date: '2025-07-20',
    location: 'Main Square',
    image: '/images/fair.jpg'
  }
];

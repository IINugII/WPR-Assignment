# Community Portal Project

## Overview

Starter boilerplate for a Node.js + Express + EJS website.

## Instructions

1. Run `npm install` to install dependencies.
2. Use `npm run dev` to start the development server with nodemon.
3. Add your own route handlers and middleware as needed.
